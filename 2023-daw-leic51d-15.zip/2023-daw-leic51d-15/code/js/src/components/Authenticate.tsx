import * as React from 'react'

export function Authenticate() : React.ReactElement{


    return(<div><p>Register or Login</p></div>)
}