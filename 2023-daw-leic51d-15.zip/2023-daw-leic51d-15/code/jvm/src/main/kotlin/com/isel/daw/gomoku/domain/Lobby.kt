package com.isel.daw.gomoku.domain

class Lobby {
}