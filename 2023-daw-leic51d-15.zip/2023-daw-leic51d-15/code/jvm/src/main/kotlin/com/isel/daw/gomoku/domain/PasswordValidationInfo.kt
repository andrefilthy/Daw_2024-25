package com.isel.daw.gomoku.domain

data class PasswordValidationInfo(
    val validationInfo : String
)