package com.isel.daw.gomoku.domain

class TokenValidationInfo (
    val validationInfo : String
)