package com.isel.daw.gomoku.hypermedia

@JvmInline
value class LinkRelation(
    val value: String
)