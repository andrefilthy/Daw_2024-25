package com.isel.daw.gomoku.domain

data class Round(val player : User, val play : Play)
