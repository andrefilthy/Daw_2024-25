rootProject.name = "gomoku"
