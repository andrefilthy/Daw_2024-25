# DAW project

You can check the relevant project documents at:
[API Documentation](./docs/APIdoc.md)

## Dev Info
```
Jorge Reis - 44771 A44771@alunos.isel.pt jorgeheaton4@gmail.com
Hugo Martins - 44832 a44832@alunos.isel.pt darkpixelpt@gmail.com
André Ramalho - 44799 a44799@alunos.isel.pt andremalvesramalho@gmail.com
```
